# -*- coding: utf-8 -*-
import json
import os
import sys
import uuid
import time
import urllib.request
import urllib.parse
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import xenon_cast_config

SERVICE_LOCK = xbmcvfs.translatePath("special://profile/addon_data/skin.xenon/casthelper-service.lock")
HOME_WINDOW_ID = 10000

# Widget container IDs used by your skin
WIDGET_IDS = list(range(8000, 8046))  # 8000–8045, adjust if needed

TMDB_API_BASE = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p"
DEFAULT_TMDB_CREDENTIAL = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmNTYwOGZiYTZhYjQ5ZTk5ODU4MjhiMzVkNTY1MzMyMSIsIm5iZiI6MTUzMDI2NzI0OS44NDcwMDAxLCJzdWIiOiI1YjM2MDY3MTkyNTE0MTNjOTMwMjkzZDMiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.sY0aCEb0tkFBHMJIxNRMbjYEmBu1aQF7z-uzRhu_134"


def log(msg):
    xbmc.log("[CastHelper] %s" % msg, xbmc.LOGINFO)


def _setting(setting_id):
    try:
        return (xenon_cast_config.read().get(setting_id) or "").strip()
    except Exception:
        return ""


def get_settings():
    credential = _setting("tmdb_api_key")
    bearer_token = _setting("tmdb_bearer_token")

    if bearer_token:
        credential = bearer_token

    # Fallback to hardcoded default if Kodi settings are empty.
    if not credential:
        credential = DEFAULT_TMDB_CREDENTIAL

    language = _setting("language") or "en-US"
    try:
        max_cast = max(1, min(50, int(_setting("max_cast") or "20")))
    except ValueError:
        max_cast = 5
    return credential, language, max_cast


def is_bearer_credential(credential):
    credential = (credential or "").strip()
    if credential.lower().startswith("bearer "):
        return True
    # TMDb API Read Access Tokens are JWTs and usually begin with eyJ... and contain
    # two dots. The v3 API key is a short hexadecimal string, so this is safe enough
    # for deciding which authentication method to use.
    return credential.startswith("eyJ") and credential.count(".") >= 2


def get_bearer_token(credential):
    credential = (credential or "").strip()
    if credential.lower().startswith("bearer "):
        return credential[7:].strip()
    return credential


def fetch_tmdb_json(credential, path, params=None, timeout=10):
    """Fetch JSON from TMDb using either a v3 API key or v4 read access token."""
    credential = (credential or "").strip()
    if not credential:
        return None

    if not path.startswith("/"):
        path = "/" + path

    params = dict(params or {})
    headers = {"Accept": "application/json"}

    if is_bearer_credential(credential):
        headers["Authorization"] = "Bearer %s" % get_bearer_token(credential)
    else:
        params["api_key"] = credential

    url = TMDB_API_BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode("utf-8")
        except Exception:
            detail = ""
        if e.code == 401:
            log("TMDb authentication failed (HTTP 401). The configured credential was rejected. "
                "Use a valid TMDb v3 API Key or v4/API Read Access Token. %s" % detail)
        else:
            log("HTTP error fetching info from TMDb: %s" % e.code)
    except Exception as e:
        log("Error fetching info from TMDb: %s" % type(e).__name__)
    return None


def get_focused_widget():
    """
    Return the ID of the widget container that currently has focus, or None.
    """
    for cid in WIDGET_IDS:
        if xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
            return cid
    return None


def get_tmdb_id_for_widget(widget_id):
    """
    Try to find a TMDb ID for the focused item in the given widget.
    Strategy:
      1) Use TMDb Helper's global property if available
      2) Fall back to common listitem properties
      3) Fall back to uniqueid(tmdb)
      4) As a last resort, parse the tmdb_id from the plugin URL
         (for favourites / Trakt 'next episodes' etc.)
    Returns (tmdb_id, media_type) where media_type is 'movie' or 'tv'.
    """
    # 1) TMDb Helper global property if present
    tmdb_id = xbmc.getInfoLabel("Window(Home).Property(TMDbHelper.ListItem.TMDB_Id)")
    if tmdb_id:
        media_type = xbmc.getInfoLabel("Window(Home).Property(TMDbHelper.ListItem.Type)")
        if media_type.lower() not in ("movie", "tv"):
            media_type = xbmc.getInfoLabel("Container(%d).ListItem.DBType" % widget_id)
        return tmdb_id, (media_type or "movie")

    # 2) Direct listitem property: tmdb_id
    tmdb_id = xbmc.getInfoLabel("Container(%d).ListItem.Property(tmdb_id)" % widget_id)
    if tmdb_id:
        media_type = xbmc.getInfoLabel("Container(%d).ListItem.DBType" % widget_id)
        return tmdb_id, (media_type or "movie")

    # 3) Unique ID 'tmdb' if set
    tmdb_id = xbmc.getInfoLabel("Container(%d).ListItem.UniqueId(tmdb)" % widget_id)
    if tmdb_id:
        media_type = xbmc.getInfoLabel("Container(%d).ListItem.DBType" % widget_id)
        return tmdb_id, (media_type or "movie")

    # 4) Parse TMDb id from plugin URL for TMDb Helper favourites / Trakt lists
    path = xbmc.getInfoLabel("Container(%d).ListItem.FilenameAndPath" % widget_id)
    if not path:
        path = xbmc.getInfoLabel("Container(%d).ListItem.FileNameAndPath" % widget_id)

    if path.startswith("plugin://plugin.video.themoviedb.helper"):
        try:
            parsed = urllib.parse.urlparse(path)
            qs = urllib.parse.parse_qs(parsed.query)
            tmdb_id = (qs.get("tmdb_id") or [""])[0]
            media_type = (qs.get("tmdb_type") or ["tv"])[0]  # default to 'tv' for next episodes
            if tmdb_id:
                return tmdb_id, media_type or "tv"
        except Exception as e:
            log("Error parsing tmdb_id from path: %s" % e)

    return None, None



def build_image_url(path, size="w185"):
    """
    Build a TMDb image URL from a relative path.
    """
    if not path:
        return ""
    return "%s/%s%s" % (TMDB_IMAGE_BASE, size, path)


def fetch_cast_and_info_from_tmdb(api_key, language, tmdb_id, media_type, max_cast):
    """
    Fetch cast and extra metadata from TMDb using the given ID and media type.
    Returns (cast_list, info_dict)
      cast_list: list of dicts: {name, character, thumb}
      info_dict: {year, genres, rating, votes, certification, director,
                  studio, studio_logo, network, network_logo}
    """
    result_cast = []
    result_info = {}

    if not api_key or not tmdb_id:
        return result_cast, result_info

    media_type = (media_type or "movie").lower()
    if media_type in ("tv", "tvshow"):
        path = "/tv/%s" % tmdb_id
        append = "credits,content_ratings"
    else:
        path = "/movie/%s" % tmdb_id
        append = "credits,release_dates"

    params = {
        "language": language,
        "append_to_response": append,
    }

    data = fetch_tmdb_json(api_key, path, params=params, timeout=10)
    if not data:
        return result_cast, result_info

    # ---- Cast ----
    credits = data.get("credits", {})
    for person in credits.get("cast", [])[:max_cast]:
        name = person.get("name") or ""
        character = person.get("character") or ""
        profile = person.get("profile_path") or ""
        thumb = build_image_url(profile, size="w185") if profile else ""
        result_cast.append({
            "name": name,
            "character": character,
            "thumb": thumb,
        })

    # ---- Basic info: year, genres, rating, votes ----
    if media_type in ("tv", "tvshow"):
        first_air = data.get("first_air_date") or ""
        year = first_air[:4] if len(first_air) >= 4 else ""
    else:
        release_date = data.get("release_date") or ""
        year = release_date[:4] if len(release_date) >= 4 else ""

    genres = ", ".join(
        g.get("name")
        for g in (data.get("genres") or [])
        if g.get("name")
    )

    vote_avg = data.get("vote_average")
    rating = ""
    if isinstance(vote_avg, (int, float)) and vote_avg > 0:
        rating = "%.1f" % vote_avg

    vote_count = data.get("vote_count")
    votes = str(vote_count) if isinstance(vote_count, int) and vote_count > 0 else ""

    # ---- Certification / content rating ----
    certification = ""
    try:
        if media_type in ("tv", "tvshow"):
            cr = (data.get("content_ratings") or {}).get("results") or []
            # Prefer US rating, else first non-empty
            chosen = None
            for r in cr:
                if (r.get("iso_3166_1") or "").upper() == "US" and r.get("rating"):
                    chosen = r
                    break
            if not chosen:
                for r in cr:
                    if r.get("rating"):
                        chosen = r
                        break
            if chosen:
                certification = chosen.get("rating") or ""
        else:
            rd_results = (data.get("release_dates") or {}).get("results") or []
            chosen = None
            # Prefer US release cert
            for r in rd_results:
                if (r.get("iso_3166_1") or "").upper() == "US":
                    for rd in r.get("release_dates") or []:
                        if rd.get("certification"):
                            chosen = rd
                            break
                if chosen:
                    break
            if not chosen:
                for r in rd_results:
                    for rd in r.get("release_dates") or []:
                        if rd.get("certification"):
                            chosen = rd
                            break
                    if chosen:
                        break
            if chosen:
                certification = chosen.get("certification") or ""
    except Exception as e:
        log("Error parsing certification: %s" % e)

    # ---- Director / creator ----
    director = ""
    try:
        crew = credits.get("crew") or []
        if media_type in ("tv", "tvshow"):
            # Try created_by first
            created_by = data.get("created_by") or []
            if created_by:
                director = created_by[0].get("name") or ""
            if not director:
                # Fallback to "Director" or "Executive Producer" from crew
                for c in crew:
                    job = (c.get("job") or "").lower()
                    if job == "director":
                        director = c.get("name") or ""
                        break
                if not director:
                    for c in crew:
                        job = (c.get("job") or "").lower()
                        if "producer" in job:
                            director = c.get("name") or ""
                            break
        else:
            for c in crew:
                if (c.get("job") or "").lower() == "director":
                    director = c.get("name") or ""
                    break
    except Exception as e:
        log("Error parsing director/creator: %s" % e)

    # ---- Studio / production company ----
    studio = ""
    studio_logo = ""
    try:
        companies = data.get("production_companies") or []
        for comp in companies:
            logo_path = comp.get("logo_path") or ""
            if logo_path:
                studio = comp.get("name") or ""
                studio_logo = build_image_url(logo_path, size="w185")
                break
    except Exception as e:
        log("Error parsing studio info: %s" % e)

    # ---- Network (TV) ----
    network = ""
    network_logo = ""
    try:
        if media_type in ("tv", "tvshow"):
            networks = data.get("networks") or []
            if networks:
                n = networks[0]
                network = n.get("name") or ""
                logo_path = n.get("logo_path") or ""
                if logo_path:
                    network_logo = build_image_url(logo_path, size="w185")
    except Exception as e:
        log("Error parsing network info: %s" % e)

    result_info = {
        "year": year,
        "genres": genres,
        "rating": rating,
        "votes": votes,
        "certification": certification,
        "director": director,
        "studio": studio,
        "studio_logo": studio_logo,
        "network": network,
        "network_logo": network_logo,
    }

    return result_cast, result_info


def set_cast_properties(cast):
    """
    Expose the given cast list (list of dicts) as window properties:
      MyCast.1.Name, MyCast.1.Role, MyCast.1.Thumb, etc.
    """
    win = xbmcgui.Window(HOME_WINDOW_ID)
    _, _, max_cast = get_settings()

    for i in range(1, max_cast + 1):
        idx = i - 1
        if idx < len(cast):
            person = cast[idx]
            win.setProperty("MyCast.%d.Name" % i, person.get("name", ""))
            win.setProperty("MyCast.%d.Role" % i, person.get("character", ""))
            win.setProperty("MyCast.%d.Thumb" % i, person.get("thumb", ""))
        else:
            win.clearProperty("MyCast.%d.Name" % i)
            win.clearProperty("MyCast.%d.Role" % i)
            win.clearProperty("MyCast.%d.Thumb" % i)


def set_info_properties(info):
    """
    Expose extra TMDb metadata as window properties:
      MyInfo.Year, MyInfo.Genres, MyInfo.Rating, MyInfo.Votes,
      MyInfo.Certification, MyInfo.Director,
      MyInfo.Studio, MyInfo.StudioLogo,
      MyInfo.Network, MyInfo.NetworkLogo
    """
    win = xbmcgui.Window(HOME_WINDOW_ID)

    def set_prop(key, value):
        win.setProperty("MyInfo.%s" % key, value or "")

    set_prop("Year", info.get("year", ""))
    set_prop("Genres", info.get("genres", ""))
    set_prop("Rating", info.get("rating", ""))
    set_prop("Votes", info.get("votes", ""))
    set_prop("Certification", info.get("certification", ""))
    set_prop("Director", info.get("director", ""))
    set_prop("Studio", info.get("studio", ""))
    set_prop("StudioLogo", info.get("studio_logo", ""))
    set_prop("Network", info.get("network", ""))
    set_prop("NetworkLogo", info.get("network_logo", ""))

    # Optional: also alias some of these into TMDbHelper.* namespace so existing
    # skin code that reads TMDbHelper.ListItem.Year/Genre/Rating can benefit.
    win.setProperty("TMDbHelper.ListItem.Year", info.get("year", ""))
    win.setProperty("TMDbHelper.ListItem.Genre", info.get("genres", ""))
    win.setProperty("TMDbHelper.ListItem.Rating", info.get("rating", ""))
    win.setProperty("TMDbHelper.ListItem.Certification", info.get("certification", ""))


def clear_cast_properties():
    win = xbmcgui.Window(HOME_WINDOW_ID)
    _, _, max_cast = get_settings()
    for i in range(1, max_cast + 1):
        win.clearProperty("MyCast.%d.Name" % i)
        win.clearProperty("MyCast.%d.Role" % i)
        win.clearProperty("MyCast.%d.Thumb" % i)


def clear_info_properties():
    win = xbmcgui.Window(HOME_WINDOW_ID)
    keys = [
        "Year", "Genres", "Rating", "Votes", "Certification",
        "Director", "Studio", "StudioLogo", "Network", "NetworkLogo",
    ]
    for key in keys:
        win.clearProperty("MyInfo.%s" % key)
    # Also clear aliases we set into TMDbHelper namespace
    for key in ("Year", "Genre", "Rating", "Certification"):
        win.clearProperty("TMDbHelper.ListItem.%s" % key)


def skin_active():
    path = xbmcvfs.translatePath('special://skin/').replace('\\', '/').rstrip('/')
    return path.rsplit('/', 1)[-1].lower() == 'skin.xenon'


def acquire_service_lock():
    os.makedirs(os.path.dirname(SERVICE_LOCK), exist_ok=True)
    token = uuid.uuid4().hex
    for _ in range(2):
        try:
            with open(SERVICE_LOCK, 'x') as stream:
                stream.write(token)
            return token
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(SERVICE_LOCK) < 60:
                    return None
                os.unlink(SERVICE_LOCK)
            except FileNotFoundError:
                pass
    return None


def release_service_lock(token):
    try:
        with open(SERVICE_LOCK) as stream:
            if stream.read() != token:
                return
        os.unlink(SERVICE_LOCK)
    except FileNotFoundError:
        pass


def run_loop():
    api_key, language, max_cast = get_settings()
    monitor = xbmc.Monitor()
    last_tmdb_id = None
    last_media_type = None

    if not api_key:
        log("No TMDb API key set in add-on settings. Cast helper will idle.")
        # Still run the loop so we can react if user sets key later.
    else:
        log("Cast & info helper started.")

    try:
        while not monitor.abortRequested():
            os.utime(SERVICE_LOCK, None)
            # Suspend during flavor switches and while another skin is active.
            if not skin_active():
                last_tmdb_id = None
                last_media_type = None
                if monitor.waitForAbort(0.7):
                    break
                continue
            # Only bother when Home is visible
            if xbmc.getCondVisibility("Window.IsVisible(home)"):
                widget_id = get_focused_widget()
                if widget_id:
                    tmdb_id, media_type = get_tmdb_id_for_widget(widget_id)

                    if tmdb_id and (tmdb_id != last_tmdb_id or media_type != last_media_type):
                        api_key, language, max_cast = get_settings()
                        if api_key:
                            cast, info = fetch_cast_and_info_from_tmdb(
                                api_key, language, tmdb_id, media_type, max_cast
                            )
                            if not skin_active():
                                continue
                            set_cast_properties(cast)
                            set_info_properties(info)
                            last_tmdb_id = tmdb_id
                            last_media_type = media_type
                        else:
                            clear_cast_properties()
                            clear_info_properties()
                    # If no tmdb_id, clear properties so skin hides the row
                    elif not tmdb_id:
                        clear_cast_properties()
                        clear_info_properties()
                        last_tmdb_id = None
                        last_media_type = None

            # Sleep a bit; react faster than a sloth, slower than a CPU hog
            if monitor.waitForAbort(0.7):
                break

    finally:
        if skin_active():
            clear_cast_properties()
            clear_info_properties()
        log("Cast & info helper stopped.")


def run():
    token = acquire_service_lock()
    if token is None:
        return
    try:
        run_loop()
    finally:
        release_service_lock(token)


if __name__ == "__main__":
    run()
