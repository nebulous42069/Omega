import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://diggz1.me/Wizard/Txts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://diggz1.me/Wizard/Txts/wizard_notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
