
# AuraMod for Matrix

Please read [wiki](https://github.com/SerpentDrago/skin.auraflix/wiki) for Matrix Install  and post install instructions 

![image](https://user-images.githubusercontent.com/21133858/119548063-d2253d80-bd63-11eb-8db7-a1d6062788b2.png)
