Place two TTF files here and rename them:
- Inter-Regular.ttf
- Inter-SemiBold.ttf

You can use any open-source fonts; just keep these filenames.
The addon references them via Fonts.xml so font sizes remain consistent across skins.
