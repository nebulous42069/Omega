from reauthorize.modules import sync_support
import xbmc, xbmcaddon
import xbmcvfs
import os

from pathlib import Path
from reauthorize.modules import control
from libs.common import var

char_remov = ["'", ",", ")","("]

#Account Manager All-Debrid
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_ad_username = accountmgr.getSetting("alldebrid.username")
your_ad_token = accountmgr.getSetting("alldebrid.token")


from reauthorize.modules import sync_support
xbmcaddon = sync_support.addon_api(xbmcaddon)
class Auth:
    def alldebrid_auth(self):
#Seren AD
        try:
                if xbmcvfs.exists(var.chk_seren): #Check that the addon is installed and settings.xml exists
                        
                        #Get add-on setting to compare
                        chk_auth_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("alldebrid.apikey")
                        chk_auth_seren_rd = xbmcaddon.Addon('plugin.video.seren').getSetting("rd.auth")
                        chk_auth_seren_pm = xbmcaddon.Addon('plugin.video.seren').getSetting("premiumize.token")
                        if sync_support.needs('plugin.video.seren', [('alldebrid.username',your_ad_username),('alldebrid.apikey',your_ad_token)]):

                                #Write data to settings.xml
                                addon = xbmcaddon.Addon("plugin.video.seren")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.apikey", your_ad_token)

                                premium_stat = ("Premium")
                                addon.setSetting("alldebrid.premiumstatus", premium_stat)
                                
                                #Enable authorized debrid services
                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("alldebrid.enabled", enabled_ad)

                                if str(chk_auth_seren_rd) != '': #Check if Real-Debrid is authorized
                                        enabled_rd = ("true")
                                        addon.setSetting("realdebrid.enabled", enabled_rd)
                                else:
                                        enabled_rd = ("false")
                                        addon.setSetting("realdebrid.enabled", enabled_rd)
                        
                                if str(chk_auth_seren_pm) != '': #Check if Premiumize is authorized
                                        enabled_pm = ("true")
                                        addon.setSetting("premiumize.enabled", enabled_pm)
                                else:
                                        enabled_pm = ("false")
                                        addon.setSetting("premiumize.enabled", enabled_pm)
        except:
                sync_support.failed('plugin.video.seren')
                xbmc.log('%s: Seren All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Coalition AD
        try:
                if xbmcvfs.exists(var.chk_coal):
                        chk_auth_coal = xbmcaddon.Addon('plugin.video.coalition').getSetting("ad.token")
                        chk_auth_coal_rd = xbmcaddon.Addon('plugin.video.coalition').getSetting("rd.token")
                        chk_auth_coal_pm = xbmcaddon.Addon('plugin.video.coalition').getSetting("pm.token")
                        if sync_support.needs('plugin.video.coalition', [('ad.account_id',your_ad_username),('ad.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.coalition")
                                addon.setSetting("ad.account_id", your_ad_username)
                                addon.setSetting("ad.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("ad.enabled", enabled_ad)

                                if str(chk_auth_coal_rd) != '':
                                        enabled_rd = ("true")
                                        addon.setSetting("rd.enabled", enabled_rd)
                                else:
                                        enabled_rd = ("false")
                                        addon.setSetting("rd.enabled", enabled_rd)
                        
                                if str(chk_auth_coal_pm) != '':
                                        enabled_pm = ("true")
                                        addon.setSetting("pm.enabled", enabled_pm)
                                else:
                                        enabled_pm = ("false")
                                        addon.setSetting("pm.enabled", enabled_pm)
        except:
                sync_support.failed('plugin.video.coalition')
                xbmc.log('%s: Coalition All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #POV AD
        try:
                if xbmcvfs.exists(var.chk_pov):
                        chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("ad.token")
                        chk_auth_pov_rd = xbmcaddon.Addon('plugin.video.pov').getSetting("rd.token")
                        chk_auth_pov_pm = xbmcaddon.Addon('plugin.video.pov').getSetting("pm.token")
                        if sync_support.needs('plugin.video.pov', [('ad.account_id',your_ad_username),('ad.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.pov")
                                addon.setSetting("ad.account_id", your_ad_username)
                                addon.setSetting("ad.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("ad.enabled", enabled_ad)

                                if str(chk_auth_pov_rd) != '':
                                        enabled_rd = ("true")
                                        addon.setSetting("rd.enabled", enabled_rd)
                                else:
                                        enabled_rd = ("false")
                                        addon.setSetting("rd.enabled", enabled_rd)
                        
                                if str(chk_auth_pov_pm) != '':
                                        enabled_pm = ("true")
                                        addon.setSetting("pm.enabled", enabled_pm)
                                else:
                                        enabled_pm = ("false")
                                        addon.setSetting("pm.enabled", enabled_pm)
        except:
                sync_support.failed('plugin.video.pov')
                xbmc.log('%s: POV All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass                

    #Umbrella AD
        try:
                if xbmcvfs.exists(var.chk_umb):
                        chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("alldebridtoken")
                        chk_auth_umb_rd = xbmcaddon.Addon('plugin.video.umbrella').getSetting("realdebridtoken")
                        chk_auth_umb_pm = xbmcaddon.Addon('plugin.video.umbrella').getSetting("premiumizetoken")
                        if sync_support.needs('plugin.video.umbrella', [('alldebridusername',your_ad_username),('alldebridtoken',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.umbrella")
                                addon.setSetting("alldebridusername", your_ad_username)
                                addon.setSetting("alldebridtoken", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("alldebrid.enable", enabled_ad)

                                if str(chk_auth_umb_rd) != '':
                                        enabled_rd = ("true")
                                        addon.setSetting("alldebrid.enable", enabled_rd)
                                else:
                                        enabled_rd = ("false")
                                        addon.setSetting("realdebrid.enable", enabled_rd)
                        
                                if str(chk_auth_umb_pm) != '':
                                        enabled_pm = ("true")
                                        addon.setSetting("premiumize.enable", enabled_pm)
                                else:
                                        enabled_pm = ("false")
                                        addon.setSetting("premiumize.enable", enabled_pm)
        except:
                sync_support.failed('plugin.video.umbrella')
                xbmc.log('%s: Umbrella All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Infinity AD
        try:
                if xbmcvfs.exists(var.chk_infinity):
                        chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("alldebridtoken")
                        chk_auth_infinity_rd = xbmcaddon.Addon('plugin.video.infinity').getSetting("realdebridtoken")
                        chk_auth_infinity_pm = xbmcaddon.Addon('plugin.video.infinity').getSetting("premiumizetoken")
                        if sync_support.needs('plugin.video.infinity', [('alldebridusername',your_ad_username),('alldebridtoken',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.infinity")
                                addon.setSetting("alldebridusername", your_ad_username)
                                addon.setSetting("alldebridtoken", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("alldebrid.enable", enabled_ad)

                                if str(chk_auth_infinity_rd) != '':
                                        enabled_rd = ("true")
                                        addon.setSetting("alldebrid.enable", enabled_rd)
                                else:
                                        enabled_rd = ("false")
                                        addon.setSetting("realdebrid.enable", enabled_rd)
                        
                                if str(chk_auth_infinity_pm) != '':
                                        enabled_pm = ("true")
                                        addon.setSetting("premiumize.enable", enabled_pm)
                                else:
                                        enabled_pm = ("false")
                                        addon.setSetting("premiumize.enable", enabled_pm)
        except:
                sync_support.failed('plugin.video.infinity')
                xbmc.log('%s: Infinity All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #Shadow AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_shadow):
                        chk_auth_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("alldebrid.token")
                        chk_auth_shadow_rd = xbmcaddon.Addon('plugin.video.shadow').getSetting("rd.auth")
                        chk_auth_shadow_pm = xbmcaddon.Addon('plugin.video.shadow').getSetting("premiumize.token")
                        if sync_support.needs('plugin.video.shadow', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                        
                                addon = xbmcaddon.Addon("plugin.video.shadow")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("debrid_use_ad", enabled_ad)

                                if str(chk_auth_shadow_rd) != '':
                                        rd_use = ("true")
                                        addon.setSetting("debrid_use_rd", rd_use)
                                else:
                                        rd_use = ("false")
                                        addon.setSetting("debrid_use_rd", rd_use)
                        
                                if str(chk_auth_shadow_pm) != '':
                                        pm_use = ("true")
                                        addon.setSetting("debrid_use_pm", pm_use)
                                else:
                                        pm_use = ("false")
                                        addon.setSetting("debrid_use_pm", pm_use)
        except:
                sync_support.failed('plugin.video.shadow')
                xbmc.log('%s: Shadow All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Blue Balls AD
        try:


                if xbmcvfs.exists(var.chk_blueballs):
                        chk_auth_blueballs = xbmcaddon.Addon('plugin.video.blueballs').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.blueballs', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.blueballs")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                d_use = ("true")
                                addon.setSetting("debrid_use", d_use)

                                d_select = ("2")
                                addon.setSetting("debrid_select", d_select)
        except:
                sync_support.failed('plugin.video.blueballs')
                xbmc.log('%s: Blue Balls All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Twisted AD
        try:


                if xbmcvfs.exists(var.chk_twisted):
                        chk_auth_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("alldebrid.token")
                        chk_auth_twisted_rd = xbmcaddon.Addon('plugin.video.twisted').getSetting("rd.auth")
                        chk_auth_twisted_pm = xbmcaddon.Addon('plugin.video.twisted').getSetting("premiumize.token")
                        if sync_support.needs('plugin.video.twisted', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.twisted")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("debrid_use_ad", enabled_ad)

                                if str(chk_auth_twisted_rd) != '':
                                        rd_use = ("true")
                                        addon.setSetting("debrid_use_rd", rd_use)
                                else:
                                        rd_use = ("false")
                                        addon.setSetting("debrid_use_rd", rd_use)

                                if str(chk_auth_twisted_pm) != '':
                                        pm_use = ("true")
                                        addon.setSetting("debrid_use_pm", pm_use)
                                else:
                                        pm_use = ("false")
                                        addon.setSetting("debrid_use_pm", pm_use)
        except:
                sync_support.failed('plugin.video.twisted')
                xbmc.log('%s: Twisted All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Aliunde K19 AD
        try:
                if xbmcvfs.exists(var.chk_aliunde):
                        chk_auth_aliunde = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("alldebrid.token")
                        chk_auth_aliunde_rd = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("rd.auth")
                        chk_auth_aliunde_pm = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("premiumize.token")
                        if sync_support.needs('plugin.video.aliundek19', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.aliundek19")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("debrid_use_ad", enabled_ad)

                                if str(chk_auth_aliunde_rd) != '':
                                        rd_use = ("true")
                                        addon.setSetting("debrid_use_rd", rd_use)
                                else:
                                        rd_use = ("false")
                                        addon.setSetting("debrid_use_rd", rd_use)

                                if str(chk_auth_aliunde_pm) != '':
                                        pm_use = ("true")
                                        addon.setSetting("debrid_use_pm", pm_use)
                                else:
                                        pm_use = ("false")
                                        addon.setSetting("debrid_use_pm", pm_use)
        except:
                sync_support.failed('plugin.video.aliundek19')
                xbmc.log('%s: Aliunde K19 All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
                
    #Ghost AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_ghost):
                        chk_auth_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.ghost', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                                
                                addon = xbmcaddon.Addon("plugin.video.ghost")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                d_use = ("true")
                                addon.setSetting("debrid_use", d_use)
                                
                                d_select = ("2")
                                addon.setSetting("debrid_select", d_select)
        except:
                sync_support.failed('plugin.video.ghost')
                xbmc.log('%s: Ghost All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Base AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_base):
                        chk_auth_base = xbmcaddon.Addon('plugin.video.base').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.base', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.base")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                d_select = ("2")
                                addon.setSetting("debrid_select", d_select)
        except:
                sync_support.failed('plugin.video.base')
                xbmc.log('%s: Base All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Chains AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_chains):
                        chk_auth_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.thechains', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):

                                addon = xbmcaddon.Addon("plugin.video.thechains")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                d_use = ("true")
                                addon.setSetting("debrid_use", d_use)
                                
                                d_select = ("2")
                                addon.setSetting("debrid_select", d_select)
        except:
                sync_support.failed('plugin.video.thechains')
                xbmc.log('%s: Chains All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Patriot AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_patriot):
                        chk_auth_patriot = xbmcaddon.Addon('plugin.video.patriot').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.patriot', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                                
                                addon = xbmcaddon.Addon("plugin.video.patriot")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                d_use = ("true")
                                addon.setSetting("debrid_use", d_use)
                                
                                d_select = ("2")
                                addon.setSetting("debrid_select", d_select)
        except:
                sync_support.failed('plugin.video.patriot')
                xbmc.log('%s: Patriot All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Black Lightning AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_blackl):
                        chk_auth_blackl = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("alldebrid.token")
                        chk_auth_blackl_rd = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("rd.auth")
                        chk_auth_blackl_pm = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("premiumize.token")
                        if sync_support.needs('plugin.video.blacklightning', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                        
                                addon = xbmcaddon.Addon("plugin.video.blacklightning")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)

                                enabled_ad = ("true" if your_ad_token and not control.wiping() else "false")
                                addon.setSetting("debrid_use_ad", enabled_ad)

                                if str(chk_auth_blackl_rd) != '':
                                        rd_use = ("true")
                                        addon.setSetting("debrid_use_rd", rd_use)
                                else:
                                        rd_use = ("false")
                                        addon.setSetting("debrid_use_rd", rd_use)
                        
                                if str(chk_auth_blackl_pm) != '':
                                        pm_use = ("true")
                                        addon.setSetting("debrid_use_pm", pm_use)
                                else:
                                        pm_use = ("false")
                                        addon.setSetting("debrid_use_pm", pm_use)
        except:
                sync_support.failed('plugin.video.blacklightning')
                xbmc.log('%s: Black Lightning All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Chains Genocide AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_genocide):
                        chk_auth_genocide = xbmcaddon.Addon('plugin.video.chainsgenocide').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.chainsgenocide', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                        
                                addon = xbmcaddon.Addon("plugin.video.chainsgenocide")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)
        except:
                sync_support.failed('plugin.video.chainsgenocide')
                xbmc.log('%s: Chains Genocide All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
        # Otaku AllDebrid
        try:
            if xbmcvfs.exists(var.chk_otaku):
                addon = xbmcaddon.Addon('plugin.video.otaku')
                token_key = 'alldebrid.token' if 'alldebrid.token' in (addon.schema or {}) else 'alldebrid.apikey'
                sync_support.put('plugin.video.otaku', [
                    ('alldebrid.username', your_ad_username),
                    (token_key, your_ad_token),
                    ('alldebrid.enabled', ('true' if your_ad_token and not control.wiping() else 'false') if your_ad_token else 'false'),
                ], wipe=control.wiping())
        except Exception:
            sync_support.failed('plugin.video.otaku')
            xbmc.log('%s: Otaku All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #All Accounts AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_allaccounts):
                        chk_auth_allaccounts = xbmcaddon.Addon('script.module.allaccounts').getSetting("alldebrid.token")
                        if sync_support.needs('script.module.allaccounts', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                        
                                addon = xbmcaddon.Addon("script.module.allaccounts")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)
        except:
                sync_support.failed('script.module.allaccounts')
                xbmc.log('%s: All Accounts All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #My Accounts AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_myaccounts):
                        chk_auth_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("alldebrid.token")
                        if sync_support.needs('script.module.myaccounts', [('alldebrid.username',your_ad_username),('alldebrid.token',your_ad_token)]):
                       
                                addon = xbmcaddon.Addon("script.module.myaccounts")
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.token", your_ad_token)
        except:
                sync_support.failed('script.module.myaccounts')
                xbmc.log('%s: My Accounts All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #ResolveURL AD
        try:
                        
                        
                if xbmcvfs.exists(var.chk_rurl):
                        # ResolveURL's AllDebrid resolver authenticates with a bearer API key.
                        # Verify credentials and enablement together; do not alter cache preferences.
                        if your_ad_token or control.wiping():
                                sync_support.put('script.module.resolveurl', [
                                    ('AllDebridResolver_token', your_ad_token),
                                    ('AllDebridResolver_enabled', 'true' if your_ad_token and not control.wiping() else 'false'),
                                ], wipe=control.wiping())
        except:
                sync_support.failed('script.module.resolveurl')
                xbmc.log('%s: ResolveURL All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Gears AD
        try:
                if sync_support.profile_ready('plugin.video.gears', var.gears_settings_db):

                    from reauthorize.modules.db import debrid_db
                    conn = debrid_db.create_conn(var.gears_settings_db)

                    with conn:
                        cursor = conn.cursor()
                        cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('ad.token',))
                        auth_ad = cursor.fetchone()
                        chk_auth_gears = str(auth_ad)
                        cursor.close()

                        for char in char_remov:
                            chk_auth_gears = chk_auth_gears.replace(char, "")

                        if not str(your_ad_token) == chk_auth_gears:
                            from reauthorize.modules.db import debrid_db
                            debrid_db.auth_gears_ad()
                            var.remake_settings()
        except:
                sync_support.failed('plugin.video.gears')
                xbmc.log('%s: Gears All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Genocide (plugin.video.genocide) AD
        try:
                if xbmcvfs.exists(var.chk_newgenocide):
                        chk_auth_newgenocide = xbmcaddon.Addon('plugin.video.genocide').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.genocide', [('alldebrid.token',your_ad_token),('alldebrid.username',your_ad_username)]):
                                addon = xbmcaddon.Addon("plugin.video.genocide")
                                addon.setSetting("alldebrid.token", your_ad_token)
                                addon.setSetting("alldebrid.username", your_ad_username)
        except:
                sync_support.failed('plugin.video.genocide')
                xbmc.log('%s: Genocide All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Orion AD
        try:
                if xbmcvfs.exists(var.chk_orion):
                        chk_auth_orion = xbmcaddon.Addon('plugin.video.orion').getSetting("ad_token")
                        if sync_support.needs('plugin.video.orion', [('ad_token',your_ad_token)]):
                                addon = xbmcaddon.Addon("plugin.video.orion")
                                addon.setSetting("ad_token", your_ad_token)
                                addon.setSetting("ad_enabled", ('true' if your_ad_token and not control.wiping() else 'false'))
        except:
                sync_support.failed('plugin.video.orion')
                xbmc.log('%s: Orion All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Red Light AD
        try:
                from reauthorize.modules.db import redlight_db
                redlight_db.push([('ad.token', your_ad_token),
                                  ('ad.account_id', your_ad_username),
                                  ('ad.enabled', ('true' if your_ad_token and not control.wiping() else 'false'))])
        except:
                sync_support.failed()
                xbmc.log('%s: Red Light All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Cosmos AD
        try:
                if xbmcvfs.exists(var.chk_cosmos):
                        chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("ad_api_key")
                        if sync_support.needs('plugin.video.cosmos', [('ad_api_key',your_ad_token)]):
                                addon = xbmcaddon.Addon("plugin.video.cosmos")
                                addon.setSetting("ad_api_key", your_ad_token)
                                addon.setSetting("ad_auth_done", ('true' if your_ad_token and not control.wiping() else 'false'))
        except:
                sync_support.failed('plugin.video.cosmos')
                xbmc.log('%s: Cosmos All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #The Archives AD
        try:
                if xbmcvfs.exists(var.chk_thearchives):
                        chk_auth_thearchives = xbmcaddon.Addon('plugin.video.thearchives').getSetting("ad.token")
                        if sync_support.needs('plugin.video.thearchives', [('ad.token',your_ad_token)]):
                                addon = xbmcaddon.Addon("plugin.video.thearchives")
                                addon.setSetting("ad.token", your_ad_token)
                                addon.setSetting("ad.enabled", ('true' if your_ad_token and not control.wiping() else 'false'))
        except:
                sync_support.failed('plugin.video.thearchives')
                xbmc.log('%s: The Archives All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Prism AD
        try:
                if xbmcvfs.exists(var.chk_prism):
                        chk_auth_prism = xbmcaddon.Addon('plugin.video.prism').getSetting("alldebrid.apikey")
                        if sync_support.needs('plugin.video.prism', [('alldebrid.apikey',your_ad_token),('alldebrid.username',your_ad_username)]):
                                addon = xbmcaddon.Addon("plugin.video.prism")
                                addon.setSetting("alldebrid.apikey", your_ad_token)
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("alldebrid.enabled", ('true' if your_ad_token and not control.wiping() else 'false'))
        except:
                sync_support.failed('plugin.video.prism')
                xbmc.log('%s: Prism All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Youtube Theater AD
        try:
                if xbmcvfs.exists(var.chk_youtubetheater):
                        chk_auth_ytheater = xbmcaddon.Addon('plugin.video.youtubetheater').getSetting("alldebrid.token")
                        if sync_support.needs('plugin.video.youtubetheater', [('alldebrid.token',your_ad_token),('alldebrid.username',your_ad_username)]):
                                addon = xbmcaddon.Addon("plugin.video.youtubetheater")
                                addon.setSetting("alldebrid.token", your_ad_token)
                                addon.setSetting("alldebrid.username", your_ad_username)
                                addon.setSetting("debrid_use_ad", ('true' if your_ad_token and not control.wiping() else 'false'))
        except:
                sync_support.failed('plugin.video.youtubetheater')
                xbmc.log('%s: Youtube Theater All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
                pass

