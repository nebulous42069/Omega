#!/usr/bin/python
# -*- coding: utf-8 -*-

from resources.lib.plugin_content import PluginContent

#main entrypoint
if __name__ == "__main__":
    PluginContent()
