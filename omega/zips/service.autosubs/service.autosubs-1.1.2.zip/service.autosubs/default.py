#!/usr/bin/python

from resources.lib.autosubs import *

AutoSubsRunner()
