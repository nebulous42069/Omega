Bundled Presets (resources/presets.json)
----------------------------------------
Add your default presets here so future add-on updates include them.
Each item requires 'name', 'm3u', and 'xml'. 'logos' is optional.

Example:
[
  {
    "name": "My Provider",
    "m3u": "https://example.com/playlist.m3u8",
    "xml": "https://example.com/guide.xml",
    "logos": "https://example.com/logos/"
  }
]

These bundled presets are shown alongside user presets saved in Settings.
You can also install (copy) them into Settings from the add-on's start menu.
