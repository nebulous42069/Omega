# Insert-Swap Kodi Favourites - To Do
![icon](https://github.com/M-Borsch/OrderFavourtites/blob/master/icon.png)  

# Program Addon: Insert-Swap Kodi Favourites - To Do List of Activities

### This is a simple & lightweight program add-on that lets you quickly reorganize your Kodi favourites that works on multiple Kodi skins.
> [!NOTE]
> - [x] - (Contxtual Popup) - ~~Add ability to display which order mode the Addon is configured~~
>
> - [x] - (Configuration Panel) - ~~Add configuration panel to Addon~~
>
> - [x] - (Selectable Order Method) - ~~Add ability to configure Order Method (Swap, Insert Before, Insert After)~~
>
> - [x] - (Icon Size) - ~~Add ability to adjust/configure the size of the thumbnails~~
>
> - [x] - (Font Size) - ~~Add ability to adjust/configure the size of the font used for label~~ 

