# plugin.video.crackle
[![GitHub release](https://img.shields.io/github/release/eracknaphobia/plugin.video.crackle.svg)](https://github.com/eracknaphobia/plugin.video.crackle/releases)
![License](https://img.shields.io/badge/license-GPL%20(%3E%3D%202)-orange)
[![Contributors](https://img.shields.io/github/contributors/eracknaphobia/plugin.video.crackle.svg)](https://github.com/eracknaphobia/plugin.video.crackle/graphs/contributors)

Watch Crackle thru Kodi

*Only on Android Devices*
