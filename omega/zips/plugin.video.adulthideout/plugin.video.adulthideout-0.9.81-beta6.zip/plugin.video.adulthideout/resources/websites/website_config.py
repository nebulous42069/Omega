website_list = [
    {
        "name": "efukt",
        "url": "https://efukt.com",
        "search_url": "https://efukt.com/search/{}",
        "module_name": "efukt",
    },
    {
        "name": "motherless",
        "url": "https://motherless.com",
        "search_url": "https://motherless.com/term/videos/{}",
        "module_name": "motherless",
    },
    {
        "name": "xvideos",
        "url": "https://xvideos.com",
        "search_url": "https://xvideos.com/?k={}",
        "module_name": "xvideos",
    },
    {
        "name": "xhamster",
        "url": "https://xhamster.com",
        "search_url": "https://xhamster.com/search/{}",
        "module_name": "xhamster",
    },
    {
        "name": "ashemaletube",
        "url": "https://ashemaletube.com",
        "search_url": "https://ashemaletube.com/search/{}",
        "module_name": "ashemaletube",
    },
    {
        "name": "hentaigasm",
        "url": "http://hentaigasm.com",
        "search_url": "http://hentaigasm.com/?s={}",
        "module_name": "hentaigasm",
    },
    {
        "name": "heavy-r",
        "url": "https://www.heavy-r.com",
        "search_url": "https://www.heavy-r.com/search/{}",
        "module_name": "heavy_r",
    },
    {
        "name": "pornxs",
        "url": "https://pornxs.com",
        "search_url": "https://pornxs.com/?s={}",
        "module_name": "pornxs",
    },
    {
        "name": "redtube",
        "url": "https://www.redtube.com",
        "search_url": "https://www.redtube.com/?search={}",
        "module_name": "redtube",
    },
    {
        "name": "vikiporn",
        "url": "https://www.vikiporn.com",
        "search_url": "https://www.vikiporn.com/search/?q={}",
        "module_name": "vikiporn",
    },
    {
        "name": "youjizz",
        "url": "https://youjizz.com",
        "search_url": "https://youjizz.com/search/{}-1.html",
        "module_name": "youjizz",
    },
    {
        "name": "porngo",
        "url": "https://www.porngo.com",
        "startpage": "/latest-updates/",
        "search_url": "https://www.porngo.com/search/{}",
        "module_name": "porngo",
    },
    {
        "name": "uflash",
        "url": "http://www.uflash.tv",
        "search_url": "/search?search_query={}&search_type=videos",
        "module_name": "uflash",
    },
    {
        "name": "luxuretv",
        "url": "https://en.luxuretv.com",
        "search_url": "https://en.luxuretv.com/search/videos/{}/" ,
        "module_name": "luxuretv",
    },
    {
        "name": "tubedupe",
        "url": "https://tubedupe.com",
        "search_url": "https://tubedupe.com/search/?q={}",
        "module_name": "tubedupe",
    },
]

website_list.sort(key=lambda x: x["name"])
